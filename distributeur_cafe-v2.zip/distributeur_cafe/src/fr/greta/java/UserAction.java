package fr.greta.java;

public class UserAction {

    public UserActionType type;

    public String valeur;

}
