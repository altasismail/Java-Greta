package fr.greta.java;

public enum Boisson {
    CAFE, DECA, DOUBLE_CAFE, INCONNUE;
}
