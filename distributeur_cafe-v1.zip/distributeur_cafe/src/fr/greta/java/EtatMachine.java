package fr.greta.java;

public enum EtatMachine {
    INIT, DONNER_ARGENT;
}
