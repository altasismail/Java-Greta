package fr.greta.java;

public enum UserActionType {
    PANNEAU,MONNAIE,INCONNUE;
}
