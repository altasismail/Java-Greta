package fr.greta.java;

public class Runner {

    public static void main(String[] args) {
        Machine machine = new Machine();
        machine.run();
    }


}
